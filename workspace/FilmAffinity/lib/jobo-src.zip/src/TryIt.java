/*********************************************
     (c) 2001/2002 by Daniel Matuschek
 *********************************************/

import java.net.URL;
import java.util.Random;

import javax.swing.text.html.HTMLDocument;

import net.matuschek.html.HtmlDocument;
import net.matuschek.http.HttpConstants;
import net.matuschek.http.HttpDoc;
import net.matuschek.http.HttpTool;

import org.apache.log4j.BasicConfigurator;

/**
 * TryIt.java
 * Created: Wed Feb 21 18:38:00 2001
 *
 * temporary class to try new developed things
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.19 $
 */




public class TryIt  {

  static Random rand = new Random();

  public static String randomString() {
    Integer i = new Integer(rand.nextInt(20000));
    return i.toString();
  }
  
  public static void main(String[] args) 
    throws Exception
  {
    BasicConfigurator.configure();
    
    HttpTool tool = new HttpTool();
    HttpDoc doc = tool.retrieveDocument(new URL("http://usul27:a1rrakis@www.atkpremium.com/members/styles/standard/pages/index.php?thispage=modelupdate&thisupdate=083735&thismodel=len004"),
					HttpConstants.GET,null);
    HtmlDocument html=new HtmlDocument(new URL("http://localhost"), doc.getContent());
    for (URL u: html.getLinks()) {
    	System.out.println(u);
    }
    
    //    System.out.println(doc);
  }
  
} // TryIt

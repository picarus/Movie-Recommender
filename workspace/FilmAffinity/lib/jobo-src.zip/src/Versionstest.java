/**
 * @author Oliver Schmidt
 *
 * Just to explore merge behaviour of cvs
 * @version $Id: Versionstest.java,v 1.7 2003/02/27 18:51:40 oliver_schmidt Exp $
 */
public class Versionstest {
 public static void main(String[] args) {
	// 1
	// 2 main branch
	// 3 two changed lines
	// 4
	// 5
	// 6
	// 7
	// 8
	// 9
	// 10
	// 11
	// 12
	// 13 fix in line 13
	// 14
	// 15
	// 16
	// 17
	// 18
	// 19
	// 20
 }
}

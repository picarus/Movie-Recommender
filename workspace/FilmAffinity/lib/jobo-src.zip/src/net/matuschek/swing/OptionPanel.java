package net.matuschek.swing;

import java.awt.*;
import javax.swing.*;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/


/**
 * An OptionPanel is a special JPane object that act a little bit like
 * JOptionPane
 * After creating the pane you can add lines that consists of a label
 * at the left side and a JComponent at the ride side.
 *
 * This is useful for simple dialogs.
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.5 $
 */
public class OptionPanel extends JPanel {

	private static final long serialVersionUID = -4539847595846318366L;

	private int count=0;
	private int inset=2;

	/**
	 * Initializes a new OptionPanel object and sets the inset value.
	 * The inset is used to have some space around the components
	 */
	public OptionPanel(int inset) {
		super();
		setLayout(new GridBagLayout());
		this.inset = inset;
	}

	/**
	 * adds a new line to the OptionPane with a label at the left side
	 * and the given Component at the right side
	 * @param labelText the text for the label
	 * @param comp a JComponent object that should be added at the right
	 * side
	 * @param fill can be java.awt.GridBagConstraints. 
	 * NONE|HORIZONTAL|VERTICAL|BOTH and describes if the component should
	 * fill the place at the right side or keep its defaults size
	 */
	public void add(String labelText, JComponent comp, int fill) {
		JLabel label = new JLabel();
		label.setText(labelText);
		GridBagConstraints consLeft = new GridBagConstraints();
		consLeft.gridx = 0;
		consLeft.gridy = count;
		consLeft.insets = new Insets(inset,inset,inset,inset);
		consLeft.anchor = GridBagConstraints.WEST;
		this.add(label, consLeft);

		GridBagConstraints consRight  = new GridBagConstraints();
		consRight.gridx = 1;
		consRight.gridy = count;
		consRight.insets = new Insets(inset,inset,inset,inset);
		consRight.fill = fill;
		consRight.anchor = GridBagConstraints.WEST;

		this.add(comp, consRight);

		count++;
	}

	/**
	 * adds a new line to the OptionPane with a label at the left side
	 * and the given Component at the right side
	 * @param labelText the text for the label
	 * @param comp a JComponent object that should be added at the right
	 * side
	 * @see #add(String, JComponent, int) (fill will be set to NONE)
	 */
	public void add(String labelText, JComponent comp) {
		add(labelText,comp,GridBagConstraints.NONE);
	}


} // OptionPanel

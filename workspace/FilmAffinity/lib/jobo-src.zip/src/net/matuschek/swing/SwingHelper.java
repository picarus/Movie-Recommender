package net.matuschek.swing;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import javax.swing.*;

/**
 * Some Swing helper functions (mostly static)
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.4 $
 */
public class SwingHelper {

  /**
   *  create a simple JTextField input field with a given length
   */
  public static JTextField createInputField(int length) {
    JTextField field = new JTextField();
    field.setColumns(length);
    return field;
  }

} // SwingHelper

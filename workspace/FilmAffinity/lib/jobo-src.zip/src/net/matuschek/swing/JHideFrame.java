package net.matuschek.swing;

import javax.swing.JFrame;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/


/**
 * This simple Frame class extends JFrame with a default event
 * handler for "close" events that does setInvisible()
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.4 $
 */
public class JHideFrame extends JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * @see JFrame#JFrame()
	 */
	public JHideFrame() {
		super();
		installCloseHandler();
	}

	/**
	 * @see JFrame#JFrame(String)
	 */
	public JHideFrame(String title) {
		super(title);
		installCloseHandler();
	}

	/**
	 * installs a event handler for closing the frame
	 */
	protected void installCloseHandler() {
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				exitForm();
			}
		}
		);
	}

	/**
	 * Overwrite this method if you want to do something special on
	 * a windowClosing event.
	 * By default this will set the window invisible.
	 */
	protected void exitForm()
	{
		setVisible(false);
	}

} // JHideFrame

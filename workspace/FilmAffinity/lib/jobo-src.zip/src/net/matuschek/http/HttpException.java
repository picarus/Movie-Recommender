package net.matuschek.http;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

/**
 * Exception that will be thrown on HTTP errors
 *
 * @author Daniel Matuschek 
 * @version $Id: HttpException.java,v 1.1 2001/04/20 11:53:23 matuschd Exp $
 */
public class HttpException extends Exception {
  
  /**
	 * 
	 */
	private static final long serialVersionUID = -7898548104576879112L;

public HttpException(String msg) {
    super(msg);
  }
}

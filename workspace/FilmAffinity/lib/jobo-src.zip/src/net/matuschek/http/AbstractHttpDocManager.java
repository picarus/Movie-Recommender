package net.matuschek.http;

import java.io.IOException;
import java.net.URL;

/**
 * Abstract base class for HttpDocManagers.
 * Implements all methods (empty) of HttpDocManager 
 *
 * @author oliver_schmidt
 * @version $Id: 
 */

public abstract class AbstractHttpDocManager implements HttpDocManager {

/**
 * Empty implementation. 
 * @see net.matuschek.http.HttpDocManager#storeDocument(net.matuschek.http.HttpDoc)
 */
	public void storeDocument(HttpDoc doc) throws DocManagerException {
	}

	/**
	 * Empty implementation. 
	 * @see net.matuschek.http.HttpDocManager#removeDocument(java.net.URL)
	 */
	public void removeDocument(URL url) {
	}

	/**
	 * Empty implementation. 
	 * @see net.matuschek.http.HttpDocManager#findDuplicate(net.matuschek.http.HttpDoc)
	 */
	public String findDuplicate(HttpDoc doc) throws IOException {
		return null;
	}

	/**
	 * Empty implementation. 
	 * @see net.matuschek.http.HttpDocManager#finish()
	 */
	public void finish() {
	}
	
	/**
	 * Empty implementation. 
	 * @see net.matuschek.http.HttpDocManager#retrieveFromCache(java.net.URL)
	 */
	public HttpDoc retrieveFromCache(URL u) {
		return null;
	}
	
	/**
	 * Empty implementation.
	 * @see net.matuschek.http.HttpDocManager#processDocument(net.matuschek.http.HttpDoc)
	 */
	public void processDocument(HttpDoc doc) throws DocManagerException {
	}

}

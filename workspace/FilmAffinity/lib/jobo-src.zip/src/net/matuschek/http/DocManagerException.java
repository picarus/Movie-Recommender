package net.matuschek.http;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/

/**
 * Exception that will be thrown by HttpDocumentManagers
 * 
 * @author Daniel Matuschek
 * @version $Revision: 1.1 $
 */
public class DocManagerException extends Exception {


/**
	 * 
	 */
	private static final long serialVersionUID = 6535142922610548628L;

/**
   * creates a DocManagerException with the given error message
   */
  public DocManagerException(String msg) {
    super(msg);
  }
  
} // DocManagerException

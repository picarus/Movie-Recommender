package net.matuschek.http;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import java.net.URL;

/**
 * Simple document manager that does nothing. For debugging purposes.
 *
 * @author Daniel Matuschek 
 * @version $Revision: 1.5 $
 */
public class HttpDocForget extends AbstractHttpDocManager {

  public void processDocument(HttpDoc doc) {
    System.out.println("forgot document "+doc.getURL().toString());
  }

  public HttpDoc retrieveFromCache(URL u) {
    return null;
  }
}

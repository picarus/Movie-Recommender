package net.matuschek.http;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

/**
 * This object represents a HTTP header. A header simply consist
 * of a name and a value separated by ":"
 *
 * @author Daniel Matuschek 
 * @version $Id: HttpHeader.java,v 1.4 2003/02/27 11:36:53 oliver_schmidt Exp $
*/
public class HttpHeader {

  /** standard headers */
  public final static String CACHE_CONTROL = "Cache-Control";
  public final static String CONTENT_LENGTH = "Content-Length";
  public final static String CONTENT_TYPE = "Content-Type";
  public final static String DATE = "Date";
  public final static String LAST_MODIFIED = "Last-Modified";
  public final static String LOCATION = "location";
  public final static String SERVER = "Server";
  public final static String SET_COOKIE = "Set-Cookie";
  public final static String TRANSFER_ENCODING = "Transfer-Encoding";
    
  /** application header used to store MD5 key of content */ 
  public final static String CONTENT_MD5 = "Content-MD5";

  /** the name (e.g. Content-Length, Set-Cookie, ...) */
  private String name="";

  /** the value (everything behind the first colon */
  private String value="";

  /**
   * initializes the HttpHeader from a given name/value pair
   */
  public HttpHeader(String name, String value) {
    this.name=name;
    this.value=value;
  }
  
  /**
   * initializes the HttpHeader from a line (request or response) 
   * @param line a HTTP header line in the format name: value
   */
  public HttpHeader(String httpLine) {
    int pos=0;
    pos=httpLine.indexOf(":");
    if (pos == -1) { return; }

    name=httpLine.substring(0,pos);
    value=httpLine.substring(pos+1).trim();
  }
  
  public String getName() { 
    return name; 
  }
  
  public void setName(String name) { 
    this.name = name; 
  }
  
  public String getValue() { 
    return value; 
  }
  
  public void setValue(String value) { 
    this.value = value; 
  }

  public String toString() {
    return toLine();
  }

  /**
   * Converts the object to a String
   * @return a name: value String
   */
  public String toLine() {
    return name+": "+value;
  }

  /**
   * Is this a Set-Cookie header ?
   * @return true if this header sets a cookie.
   */
  public boolean isSetCookie() {
    return name.equalsIgnoreCase(SET_COOKIE);
  }
  
}

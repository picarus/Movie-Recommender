package net.matuschek.spider;

import java.net.URL;

/**
 * Exception Handler for WebRobot
 * <p>
 * @author Jo Christen
 * @version $Revision: 1.1 $
 */
public interface RobotExceptionHandler {

	/**
	 * Handle exception
	 * @param robot
	 * @param url
	 * @param e
	 */	
	void handleException(WebRobot robot, URL url, Exception e);

}

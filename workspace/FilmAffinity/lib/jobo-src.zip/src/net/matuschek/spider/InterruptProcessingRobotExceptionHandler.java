package net.matuschek.spider;

import java.net.URL;


/**
 * InterruptProcessingRobotExceptionHandler
 * This is a concrete ExceptionHandler, which interupts the processing robot
 * by throwing a runtime exception.
 * <p>
 * @author cn
 * @version 0.1
 */
public class InterruptProcessingRobotExceptionHandler implements RobotExceptionHandler {

	/**
	 * This exception handler throws a runtime exception with the message of the
	 * incoming exception.
	 * @see RobotExceptionHandler#handleException(WebRobot, URL, Exception)
	 */
	public void handleException(WebRobot robot, URL url, Exception e) {
		String errorMessage = e.getMessage();
		//System.out.println("ERROR: " + errorMessage);
		//robot.stopRobot();
		throw new RuntimeException(errorMessage);
	}

}

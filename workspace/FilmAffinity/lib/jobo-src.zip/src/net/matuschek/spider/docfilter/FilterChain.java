package net.matuschek.spider.docfilter;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import java.util.Vector;

import net.matuschek.http.HttpDoc;

/**
 * This object defines a chain of DocumentFilters
 * 
 * @author Daniel Matuschek 
 * @version $Revision: 1.1 $
 */
public class FilterChain {

  /** All filters */
  Vector<DocumentFilter> filters = new Vector<DocumentFilter>();

  /**
   * Creates a new FilterChain without any installed filters
   */
  public FilterChain() {    
  }

  /**
   * Adds a new filter to the filter chain
   */
  public void add(DocumentFilter filter) {
    filters.add(filter);
  }


  /** 
   * Processes a HttpDoc by the defined filter chain
   *
   * @param doc the input document to process
   * @return a HttpDoc that is the result of filtering
   */
  public HttpDoc process(HttpDoc doc) 
    throws FilterException
  {
    for (int i=0; i<filters.size(); i++) {
      DocumentFilter filter = filters.elementAt(i);
      doc = filter.process(doc);
    }
    return doc;
  }
}

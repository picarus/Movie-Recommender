package net.matuschek.spider.docfilter;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/


/**
 * This is a generic exception that will be thrown if an error
 * occurs during filtering a document.
 * 
 * @author Daniel Matuschek 
 * @version $Id $
 */
public class FilterException extends Exception
{

	private static final long serialVersionUID = 8800962933780602077L;

	/**
	 * creates a FilterException with the given error message
	 */
	public FilterException(String msg) {
		super(msg);
	}

}

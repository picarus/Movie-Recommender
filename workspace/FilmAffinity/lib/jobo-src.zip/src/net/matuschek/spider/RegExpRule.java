package net.matuschek.spider;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import org.apache.regexp.RESyntaxException;
import org.apache.regexp.RE;

/**
 * Simple class that defines a rule based on a regular expression
 * It consists of a pattern and a action (allow or deny)
 * 
 * @author Daniel Matuschek
 * @version $Id $
 */
public class RegExpRule {
  
  public RegExpRule() {
  }

  /** 
   * Gets the value of allow
   * @return true, if this rule allows something, false if it denies
   *  something
   */
  public boolean getAllow() {
    return allow;
  }


  /** 
   * Sets the value of allow
   * @param allow true, if this rule allows something, false if it denies
   * something
   */
  public void setAllow(boolean allow) {
    this.allow = allow;
  }


  /** 
   * Gets the value of processAllowed
   * @return true, if this rule allows processing, false if it denies it
   */
  public boolean getProcessAllowed() {
	return processAllowed && allow;
  }


  /** 
   * Sets the value of processAllowed
   * @param processAllowed true, if this rule allows processing, false if it
   * denies it
   */
  public void setProcessAllowed(boolean processAllowed) {
	this.processAllowed = processAllowed;
  }
  
  /** 
   * Gets the regexp pattern
   * @return a regular expression that this rule matches
   */
  public String getPattern() {
    return pattern;
  }


  /** 
   * Sets the regexp pattern
   * @param pattern a regular expression that this rule matches
   */
  public void setPattern(String pattern) 
    throws RESyntaxException
  {
    this.expression = new RE(pattern);
    this.pattern = pattern;
  }

  /**
   * Does this rule match the given string ?
   * @param s a String
   * @return true if the regular expression matches the argument,
   * false otherwise
   */
  public boolean match(String s) {
    return expression.match(s);
  }

  private boolean allow=true;
  private boolean processAllowed=true;
  private String pattern="";
  private RE expression=new RE();
  
} // RegExpRule

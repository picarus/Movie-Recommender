package net.matuschek.spider;

import java.net.URL;


/**
 * DefaultRobotExceptionHandler
 * This is a concrete ExceptionHandler, which is used as default exception handler
 * <p>
 * @author cn
 * @version 0.1
 */
public class DefaultRobotExceptionHandler implements RobotExceptionHandler {

	/**
	 * This exception handler ignores the exception and does nothing
	 * @see RobotExceptionHandler#handleException(WebRobot, URL, Exception)
	 */
	public void handleException(WebRobot robot, URL url, Exception e) {
		// do nothing
	}

}

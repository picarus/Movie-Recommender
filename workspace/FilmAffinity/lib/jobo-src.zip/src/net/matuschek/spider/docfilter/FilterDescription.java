package net.matuschek.spider.docfilter;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/


/**
 * A descriptions for a DocFilter object
 * 
 * @author Daniel Matuschek 
 * @version $Id: FilterDescription.java,v 1.1 2001/04/25 15:23:55 matuschd Exp $
 */
public class FilterDescription {

  /** 
   * the name of this filter 
   */
  private String name;

  /** 
   * initializes a new FilterDescription with the given name
   */
  public FilterDescription(String name) {
    this.name = name;
  }

  public String getName() {
    return this.name;
  }
}

package net.matuschek.spider;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

/**
 * Callback interface for the webrobot to inform the front end
 * about the current state
 *
 * @author Daniel Matuschek <daniel@matuschek.net>
 * @version $Id: WebRobotCallback.java,v 1.1 2001/04/18 08:31:08 matuschd Exp $
 */
public interface WebRobotCallback {

  void webRobotRetrievedDoc(String url, int size);

  void webRobotUpdateQueueStatus(int length);

  void webRobotDone();

  void webRobotSleeping(boolean sleeping);

}

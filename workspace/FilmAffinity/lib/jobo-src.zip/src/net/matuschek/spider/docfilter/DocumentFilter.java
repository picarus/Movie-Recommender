package net.matuschek.spider.docfilter;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import net.matuschek.http.HttpDoc;

/**
 * This interface defines a filter for a HTTP document.
 * Objects that implement this interface will do some kind
 * of transformation on the document.
 * 
 * @author Daniel Matuschek 
 * @version $Revision: 1.5 $
 */
public interface DocumentFilter
{

  /**
   * This method filters (transforms) an HttpDoc
   */
  HttpDoc process(HttpDoc input) throws FilterException;

}

package net.matuschek.spider;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import java.net.URL;

/**
 * This interface defines a simple method that allows another
 * object (usually this will be a WebRobot) to test, if a given
 * URL is acceptable (e.g. for the WebRobot this means, it should
 * retrieve the URL).
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.3 $
 */
public interface URLCheck  {

  /**
   * Tests if the given URL is acceptable. This method is designed
   * for a WebRobot to do additional tests, if it should retrieve a
   * URL
   * @see WebRobot
   */
  boolean checkURL(URL u);
  
  /**
   * Tests if the given URL is acceptable for processing.
   * This method is designed for a WebRobot to do additional tests, if it should
   * process a URL
   * @see WebRobot
   */
  boolean checkURLForProcessing(URL u);
} // URLCheck

package net.matuschek.spider;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/


import java.util.Vector;

/**
 * Memory based implementation of the TaskList interface. Uses an
 * Vector to store the tasks. 
 * To be thread safe, all methods are synchronized.
 *
 * @author Daniel Matuschek 
 * @version $Id: MemoryTaskList.java,v 1.4 2001/07/31 12:18:52 matuschd Exp $
 * @deprecated Use the new HashedMemoryTaskList for better performance (but 
 * requires more memory)
 */
public class MemoryTaskList 
  implements TaskList 
{


  /** 
   * Task store 
   *
   * @link aggregation
   * @associates <{RobotTask}>
   */
  private Vector list = new Vector();


  /**
   * Simple constructor, does nothing special
   */
  public MemoryTaskList() {
  }


  /**
   * Add a task to the end of the list
   * @param task a RobotTask object to store in the queue
   */
  public synchronized void add(RobotTask task) {
    list.add(task);
  }


  /**
   * Add a task at the beginning of list
   * @param task a RobotTask object to store in the queue
   */
  public synchronized void addAtStart(RobotTask task) {
    list.add(0,task);
  }


  /**
   * Clean up the list, remove all objects
   */
  public synchronized void clear() {
    list.clear();
  }


  /**
   * Is this robot task stored in the list ?
   */
  public synchronized boolean contains(RobotTask task) {
    return list.contains(task);
  }


  /**
   * Remove this object from the list
   */
  public synchronized boolean remove(RobotTask task) {
    return list.remove(task);
  }

  
  /**
   * Get and remove the first element.
   * @return the first task in the list. This object will also be removed
   * from the list.
   * @exception ArrayIndexOutOfBoundsException if the list is empty
   */
  public synchronized RobotTask removeFirst()
    throws ArrayIndexOutOfBoundsException
  {
    RobotTask task = (RobotTask)list.elementAt(0);
    list.removeElementAt(0);
    return task;
  }


  /**
   * Returns the number of elements in this list
   */
  public synchronized int size() {
    return list.size();
  }


  /**
   * Get the n-th element in the list. Elements are numbered form 0 to
   * size-1.
   * @param position
   * @exception ArrayIndexOutOfBoundsException if the given position doesn't
   * exist
   */
  public synchronized RobotTask elementAt(int position) 
    throws ArrayIndexOutOfBoundsException
  {
    return (RobotTask)(list.elementAt(position));
  }

}

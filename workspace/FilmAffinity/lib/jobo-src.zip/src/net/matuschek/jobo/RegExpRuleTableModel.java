package net.matuschek.jobo;

import java.util.Vector;
import javax.swing.table.AbstractTableModel;
import net.matuschek.spider.RegExpRule;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/



/**
 * Table model to view RegExpRules
 *   
 * @author Daniel Matuschek
 * @version $ID$
 */
public class RegExpRuleTableModel 
extends AbstractTableModel 
{

	private static final long serialVersionUID = -2211969715108211170L;

	final static String[] columns = { "Allow","Pattern" };

	/** 
	 * create a new RegExpRuleTableModel associated with the given
	 * RegExpURLCheck
	 */
	public RegExpRuleTableModel(Vector rules) {
		super();
		this.rules = rules;
	}

	public int getColumnCount() {
		return columns.length;
	}

	public int getRowCount() {
		return rules.size();
	}

	public String getColumnName(int col) {
		return columns[col];
	}

	public Object getValueAt(int row, int col) {
		RegExpRule rule = (RegExpRule)rules.elementAt(row);
		if (col == 0) {
			return new Boolean(rule.getAllow());
		} else if (col == 1) {
			return rule.getPattern();
		} else {
			return null;
		}
	}

	public Class<?> getColumnClass(int col) {
		if (col == 0) {
			return Boolean.class;
		} else if (col == 1) {
			return String.class;
		} else {
			return null;
		}
	}

	/**
	 * every cell is editable
	 */
	 public boolean isCellEditable(int row, int column) {
		 return true;
	 }


	 /**
	  **/
	 public void setValueAt(Object value, int row, int col) {
		 RegExpRule rule = (RegExpRule)rules.elementAt(row);

		 if (col == 0) {
			 // allow/deny
			 rule.setAllow(((Boolean)value).booleanValue());
		 } else if (col == 1) {
			 try {
				 rule.setPattern((String)value);
			 } catch (org.apache.regexp.RESyntaxException e) {
				 // TO DO !
			 }
		 } else {
			 // this should never happen
			 return;
		 }

	 }


	 // private variables

	 Vector rules = null;

} // RegExpRuleTableModel

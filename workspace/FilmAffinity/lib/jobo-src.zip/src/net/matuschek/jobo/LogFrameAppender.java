package net.matuschek.jobo;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

/**
 *  
 * Simple object that is used to connect the JoBo LogFrame with
 * Log4J. It simply implements a Log4J Appender
 * 
 * @author Daniel Matuschek
 * @version $Id $
 */


public class LogFrameAppender extends AppenderSkeleton {  
  private LogFrame log;
  
  public LogFrameAppender(LogFrame log) {
    super();
    this.log=log;
  }

  public void append(LoggingEvent e) {
    log.addMsg(e.getMessage().toString());
  }

  public void close() {
    log.setVisible(false);
  }

  public boolean requiresLayout() {
    return false;
  }
  
} // LogFrameAppender

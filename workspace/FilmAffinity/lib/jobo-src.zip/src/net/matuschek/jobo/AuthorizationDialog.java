
/**
 * AuthorizationDialog.java
 *
 *
 * Created: Tue Feb 20 12:16:47 2001
 *
 * @author 
 * @version
 */

package net.matuschek.jobo;

import java.awt.*;
import javax.swing.*;
//Property change stuff

public class AuthorizationDialog extends JDialog {

	private static final long serialVersionUID = 1111229487527135214L;

	private String typedText = null;

	public String getValidatedText() {
		return typedText;
	}

	public AuthorizationDialog(Frame aFrame, String host, String realm) {
		super(aFrame, true);

		setTitle("Authorization required");
	}

} // AuthorizationDialog

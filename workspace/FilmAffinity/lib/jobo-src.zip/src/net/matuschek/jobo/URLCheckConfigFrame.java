package net.matuschek.jobo;

import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import net.matuschek.spider.RegExpURLCheck;
import net.matuschek.swing.JHideFrame;
import net.matuschek.swing.OptionPanel;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/




/**
 * Swing Configuration frame for the RegExpURLCheck rules
 *   
 * @author Daniel Matuschek
 * @version $Id $
 */
public class URLCheckConfigFrame extends JHideFrame {

	private static final long serialVersionUID = 7588707167267231914L;

public URLCheckConfigFrame(RegExpURLCheck check) {    
    super("URLCheck configuration");
    this.check = check;
    initComponents();
  }


  protected void initComponents() {
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
    setContentPane(mainPanel);

    OptionPanel dialogPanel = new OptionPanel(2);

    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new BoxLayout(buttonPanel,BoxLayout.X_AXIS));

    mainPanel.add(dialogPanel);
    mainPanel.add(buttonPanel);

    /**
       Input fields
     **/

    // table
    Vector rules = check.getRules();
    RegExpRuleTableModel tableModel 
      = new RegExpRuleTableModel(check.getRules());
    JTable table = new JTable(tableModel);
    JScrollPane scrollPane = new JScrollPane(table);
    dialogPanel.add(scrollPane);


    /**
       End of input fields
     **/

    /**
       Button panel
     **/
    JButton okButton = new JButton();
    okButton.setText("OK");
    okButton.addActionListener(new java.awt.event.ActionListener() {
	public void actionPerformed(java.awt.event.ActionEvent evt) {
	  updateAndHide();
	}
      });
    buttonPanel.add(okButton);

    JButton closeButton = new JButton();
    closeButton.setText("Cancel");
    closeButton.addActionListener(new java.awt.event.ActionListener() {
	public void actionPerformed(java.awt.event.ActionEvent evt) {
	  exitForm();
	}
      });
    buttonPanel.add(closeButton);

    /**
       End of button panel 
    **/

    pack ();
    updateFormFromURLCheck();
  }


  /**
     update the RegExpURLCheck form dialog
  **/
  protected void updateAndHide() {
    this.setVisible(false);
  }


  /** 
      update the content of the form field from the current robot
      settings
  **/
  protected void updateFormFromURLCheck() {
  }


  /**
     update the URLCheck settings from the current fields
     @return true if everything is okay, false otherwise
  **/
  protected boolean updateURLCheckFromForm() {
    return true;
  }

  /**********************************************************************/
  /**********************************************************************/
  /**********************************************************************/

  /** the RegExpURLCheck to configure **/
  RegExpURLCheck check = null;


  // input fields
  //

  
} // URLCheckConfigFrame

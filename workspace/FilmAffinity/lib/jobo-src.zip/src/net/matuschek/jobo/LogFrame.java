package net.matuschek.jobo;

import java.util.Vector;

import net.matuschek.swing.JHideFrame;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/


/**
 * Simple JFrame for Log4J logging
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.8 $
 */
public class LogFrame extends JHideFrame {

	private static final long serialVersionUID = 3177932656317752712L;

	/** 
	 * Creates new form LogFrame 
	 */
	public LogFrame() {
		listData = new Vector<String>();
		initComponents ();
		pack ();
	}

	/** 
	 * This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		buttonPanel = new java.awt.Panel();
		closeButton = new java.awt.Button();
		clearButton = new java.awt.Button();
		messagePanel = new javax.swing.JPanel();
		jScrollPane1 = new javax.swing.JScrollPane();
		messageList = new javax.swing.JList();
		setName("JoBo Logging");
		addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent evt) {
				exitForm();
			}
		}
		);
		closeButton.setLabel("Close");
		closeButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitForm();
			}
		}
		);
		clearButton.setLabel("Clear");
		clearButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				clearLog();
			}
		}
		);
		buttonPanel.add(clearButton);
		buttonPanel.add(closeButton);

		getContentPane().add(buttonPanel, java.awt.BorderLayout.SOUTH);

		messagePanel.setLayout(new javax.swing.BoxLayout(messagePanel, 0));

		jScrollPane1.setViewportView(messageList);

		messagePanel.add(jScrollPane1);

		getContentPane().add(messagePanel, java.awt.BorderLayout.CENTER);

	}

	public void addMsg(String msg) {
		listData.add(msg);

		// if there are to many messages, remove the first one ...
		if (listData.size() > maxLog) {
			listData.remove(0);
		}

		messageList.setListData(listData);
	}

	public void clearLog() {
		listData.clear();
		messageList.setListData(listData);
	}

	private Vector<String> listData = null;
	private static int maxLog = 2000;

	private java.awt.Panel buttonPanel;
	private java.awt.Button closeButton;
	private java.awt.Button clearButton;
	private javax.swing.JPanel messagePanel;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JList messageList;
}

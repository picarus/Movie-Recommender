package net.matuschek.jobo;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

import net.matuschek.swing.JHideFrame;
import net.matuschek.swing.OptionPanel;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/



/**
 * Configuration dialog for filters
 * 
 * @author Daniel Matuschek
 * @version $Revision: 1.3 $
 */
public class FilterConfigFrame extends JHideFrame {


	private static final long serialVersionUID = -115214206470304510L;


	public FilterConfigFrame() {    
		super("Filter configuration");
		initComponents();
	}


	protected void initComponents() {
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
		setContentPane(mainPanel);

		OptionPanel dialogPanel = new OptionPanel(2);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel,BoxLayout.X_AXIS));

		mainPanel.add(dialogPanel);
		mainPanel.add(buttonPanel);

		/** Dialog panel **/
		/** End of Dialog panel */

		/** Button panel */
		JButton okButton = new JButton();
		okButton.setText("OK");
		okButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				updateAndHide();
			}
		});
		buttonPanel.add(okButton);

		JButton closeButton = new JButton();
		closeButton.setText("Cancel");
		closeButton.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitForm();
			}
		});
		buttonPanel.add(closeButton);
		/** End of button panel */

		pack ();
	}


	/**
	 * update the settings from the form contents and hide window
	 */
	protected void updateAndHide() {
		this.setVisible(false);
	}


	/**********************************************************************/
	/**********************************************************************/
	/**********************************************************************/

}


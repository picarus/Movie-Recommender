package net.matuschek.jobo;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.matuschek.swing.JHideFrame;
import net.matuschek.swing.VerticalAlignPanel;
/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
 *********************************************/


/**
 * Frame to manage lists of AllowedURLs
 *
 * @author Daniel Matuschek
 * @version $Revision: 1.2 $
 */
public class AllowedListFrame extends JHideFrame {

	private static final long serialVersionUID = -5113419291037861467L;

	/** a Vector containing the allowed URLs as Strings */
	private Vector<String> urls = null;

	/** JList holding all URLs */
	private JList urlList = null;


	/**
	 * Initializes the object with the given list of allowed URLs
	 */
	public AllowedListFrame(Vector<String> urls) {
		super();
		this.urls = urls;
		initComponents ();
		pack ();
	}


	/** 
	 * This method is called from within the constructor to
	 * initialize the form.
	 */
	private void initComponents() {
		this.setTitle("Allowed URLs");

		JPanel completePanel = new JPanel();
		completePanel.setLayout(new GridBagLayout());


		JPanel leftPanel = new JPanel();
		GridBagConstraints consLeft  = new GridBagConstraints();
		consLeft.gridx = 0;
		consLeft.gridy = 0;
		completePanel.add(leftPanel, consLeft);


		VerticalAlignPanel rightPanel = new VerticalAlignPanel();
		GridBagConstraints consRight  = new GridBagConstraints();
		consRight.gridx = 1;
		consRight.gridy = 0;
		completePanel.add(rightPanel, consRight);


		//
		// buttons
		//
		JButton buttAdd = new JButton();
		buttAdd.setText("Add");
		buttAdd.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				addURL();
			}
		});
		rightPanel.add(buttAdd,1);

		JButton buttDelete = new JButton();
		buttDelete.setText("Delete");
		buttDelete.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				deleteURL();
			}
		});
		rightPanel.add(buttDelete,1);

		JButton buttClose = new JButton();
		buttClose.setText("Close");
		buttClose.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				exitForm();
			}
		});
		rightPanel.add(buttClose,1);

		// list
		urlList = new JList();
		urlList.setVisibleRowCount(6);
		urlList.setMinimumSize(new java.awt.Dimension(40,4));
		urlList.setListData(urls);
		JScrollPane urlScroll = new JScrollPane();
		urlScroll.setViewportView(urlList);
		leftPanel.add(urlScroll);


		getContentPane().add(completePanel);

	}

	protected void deleteURL() {
		int selected = urlList.getMinSelectionIndex();
		if (selected < 0) {
			JOptionPane.showMessageDialog(this,
					"Please select an URL");
		} else {
			String deleteURL = urls.elementAt(selected);
			int yes = 
				JOptionPane.showConfirmDialog(this,
						"Do you really want to delete "
						+deleteURL+" ?",
						"Confirm delete",
						JOptionPane.YES_NO_OPTION);
			if (yes == 0) {
				urls.removeElementAt(selected);
				urlList.clearSelection();
			}

		}
	}


	protected void addURL() {
		String newURL = JOptionPane.showInputDialog("Add URL:");
		urls.add(newURL);
		urlList.setListData(urls);
	}


}

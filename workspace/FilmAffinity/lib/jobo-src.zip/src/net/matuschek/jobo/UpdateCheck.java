package net.matuschek.jobo;

/*********************************************
    Copyright (c) 2001 by Daniel Matuschek
*********************************************/


/**
 * Checks for JoBo updates
 * 
 * @author Daniel Matuschek
 * @version $Revision: 1.2 $
 */
public class UpdateCheck extends Thread {

  /** URL where to find the latest version */
  public static String VERSION_URL="http://www.matuschek.net/software/jobo/version.txt";

  
}
  

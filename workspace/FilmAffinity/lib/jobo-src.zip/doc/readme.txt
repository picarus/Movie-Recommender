JoBo by Daniel Matuschek
------------------------

For an up-to-date documentation please have a look at the JoBo
web site at http://www.matuschek.net/jobo.html.

You will need a Java Runtime Environment 1.3 or later (on many 
System Java 1.2 is installed, it will NOT work !).



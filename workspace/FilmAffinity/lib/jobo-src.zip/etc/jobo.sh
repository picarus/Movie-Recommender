#!/bin/sh
java -Xmx256M -cp castor-0.9.2-xml.jar:jakarta-regexp-1.2.jar:Tidy.jar:log4j-core.jar:xalan.jar:xerces.jar:jobo.jar net.matuschek.jobo.JoBoSwing
